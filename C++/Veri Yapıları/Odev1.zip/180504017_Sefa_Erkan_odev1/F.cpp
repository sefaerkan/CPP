#ifndef _F_
#define _F_
#include "Gonderi.h"
#include "NakliyeArac.h"
#include "Arac.h"

Arac::Arac(int AracID=0,int AracKapasite=0,int AracSubeID=0):AracID(AracID),AracKapasite(AracKapasite),AracSubeID(AracSubeID){}//Parametreli Kurucu Fonskiyon
int Arac::getAracID(){return AracID;} //getter tan�mlama
int Arac::getAracKapasite(){return AracKapasite;}  //getter tan�mlama
int Arac::getAracSubeID(){return AracSubeID;} //getter tan�mlama
void Arac::setAracID(int AracID){this->AracID=AracID;} //Setter tan�mlama
void Arac::setAracKapasite(int AracKapasite){this->AracKapasite=AracKapasite;} //Setter tan�mlama
void Arac::setAracSubeID(int AracSubeID){this->AracSubeID=AracSubeID;} //Setter tan�mlama
void Arac::print() //Print fonksiyonu tan�mlama
{
cout<<"Arac ID:"<<AracID<<" Kapasite:"<<AracKapasite<<" Sube ID:"<<AracSubeID<<endl;
}

NakliyeArac::NakliyeArac(int GonderiID,int SubeID,string YuklemeSaati,string HareketSaati):GonderiID(GonderiID),SubeID(SubeID),YuklemeSaati(YuklemeSaati),HareketSaati(HareketSaati){}//Parametreli Kurucu Fonskiyon
int NakliyeArac::getGonderiID(){return GonderiID;} //getter tan�mlama
int NakliyeArac::getSubeID(){return SubeID;} //getter tan�mlama
string NakliyeArac::getYuklemeSaati(){return YuklemeSaati;} //getter tan�mlama
string NakliyeArac::getHareketSaati(){return HareketSaati;} //getter tan�mlama
void NakliyeArac::setGonderiID(int GonderiID ){this->GonderiID=GonderiID;} //Setter tan�mlama
void NakliyeArac::setSubeID(int SubeID){this->SubeID=SubeID;} //Setter tan�mlama
void NakliyeArac::setHareketSaati(string HareketSaati){this->HareketSaati=HareketSaati;} //Setter tan�mlama
void NakliyeArac::setYuklemeSaati(string YuklemeSaati){this->YuklemeSaati=YuklemeSaati;} //Setter tan�mlama
void NakliyeArac::print() //Print fonksiyonu tan�mlama
{
cout<<"Gonderi ID:"<<GonderiID<<" Sube ID:"<<SubeID<<" Yukleme Saati:"<<YuklemeSaati<<" Hareket Saati:"<<HareketSaati<<endl;
}

Gonderi::Gonderi(int GonderiID,int GonderiTurID,int GonderiOncelik,int GonderiHacim,int SubeID):GonderiID(GonderiID),GonderiTurID(GonderiTurID),GonderiOncelik(GonderiOncelik),GonderiHacim(GonderiHacim),SubeID(SubeID){}//Parametreli Kurucu Fonskiyon
int Gonderi::getGonderiID(){return GonderiID;} //getter tan�mlama
int Gonderi::getGonderiTurID(){return GonderiTurID;} //getter tan�mlama
int Gonderi::getGonderiOncelik(){return GonderiOncelik;} //getter tan�mlama
int Gonderi::getGonderiHacim(){return GonderiHacim;} //getter tan�mlama
int Gonderi::getSubeID(){return SubeID;} //getter tan�mlama
void Gonderi::setGonderiID(int GonderiID){this->GonderiID=GonderiID;} //Setter tan�mlama
void Gonderi::setGonderiTurID(int GonderiTurID){this->GonderiTurID=GonderiTurID;} //Setter tan�mlama
void Gonderi::setGonderiOncelik(int GonderiOncelik){this->GonderiOncelik=GonderiOncelik;} //Setter tan�mlama
void Gonderi::setGonderiHacim(int GonderiHacim){this->GonderiHacim=GonderiHacim;} //Setter tan�mlama
void Gonderi::setSubeID(int SubeID){this->SubeID=SubeID;} //Setter tan�mlama
void Gonderi::print() //Print fonksiyonu tan�mlama
{
cout<<"Gonderi ID:"<<GonderiID<<" Tur ID:"<<GonderiTurID<<" Oncelik:"<<GonderiOncelik<<"Hacim:"<<GonderiHacim<<" Sube ID:"<<SubeID;
}
#endif
