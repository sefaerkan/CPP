#include <iostream> 
using namespace std;
#ifndef _ARAC_H_
#define _ARAC_H_

class Arac{ //Ara� S�n�f tan�mlama
	private:
		int	AracID; //AracID tan�mlama
		int AracKapasite; //AracKapasite tan�mlama
		int AracSubeID; //AracSubeID tan�mlama
	public:
		Arac(int,int,int); //Parametreli Kurucu
		int getAracID(); //getter
		void setAracID(int AracID); //Setter
		int getAracKapasite();	 //getter
		void setAracKapasite(int AracKapasite); //Setter
		int getAracSubeID();	//getter
		void setAracSubeID(int AracSubeID); //Setter
		void print(); //Yazdr�ma 
};







#include "F.cpp"
#endif
