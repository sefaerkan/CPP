#include <iostream> 
using namespace std;
#ifndef _NAKLIYEARAC_H_
#define _NAKLIYEARAC_H_

class NakliyeArac{ //NakliyeArac s�n�f� tan�mlama
	private: //�zel
		int GonderiID; //GonderiID tan�mlama
		int SubeID; //SubeID tan�mlama
		string YuklemeSaati; //YuklemeSaati tan�mlama
		string HareketSaati; //HareketSaati tan�mlama
	public: //A��k
		NakliyeArac(int,int,string,string); //Parametreli Kurucu
		int getGonderiID(); //getter
		void setGonderiID(int GonderiID); //Setter
		int getSubeID();	 //getter
		void setSubeID(int SubeID); //Setter
		string getYuklemeSaati();	//getter
		void setYuklemeSaati(string YuklemeSaati); //Setter
		string getHareketSaati();	//getter
		void setHareketSaati(string HareketSaati); //Setter
		void print(); //Yazdr�ma 
};



#include "F.cpp"
#endif
