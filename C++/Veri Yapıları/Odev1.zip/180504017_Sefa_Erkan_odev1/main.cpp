#include <iostream> //Gerekli K�t�phane
#include <fstream> //Gerekli K�t�phane
#include <stdlib.h> //Gerekli K�t�phane
#include <string> //Gerekli K�t�phane
#include <sstream> //Gerekli K�t�phane
#include <locale.h> //Gerekli K�t�phane
#include "Gonderi.h" //Gerekli Header
#include "NakliyeArac.h" //Gerekli Header
#include "Arac.h" //Gerekli Header
using namespace std; //cout i�in

class Subeler{ //�ubeler class� tan�mlama
	private:
		string isim;
		int id;
	public:
		Subeler(string isim="", int id=0): isim(isim),id(id){} //�ubeler kurucu fonksiyon
		void print(){
			cout<<"Sube Isim:"<<isim<<" "<<"ID:"<<id<<endl; //Yazd�rma
		}
		int getID(){return id;} //Getter
};

template<class T>
class Node{ //Node S�n�f Tasar�m�
	public:
		Node(const T& data=T(), Node<T>* next=NULL ): data(data),next(next){} //Node Kurucu fonksiyon
		T data; //data de�i�keni
		Node<T>* next; //next de�i�keni
};
template<class T>
class list{ //Liste s�n�f tasar�m�
	Node<T>* root; //root de�i�keni
	Node<T>* tail; //tail de�i�keni
	int length; //lenght de�i�keni
	Node<T>* findPrev(Node<T>* pos){
		Node<T>* tmp=root;
		Node<T>* stop=end();
		while(tmp != stop && tmp->next != pos){
			tmp=tmp->next;
		}
		return tmp;
	}
	public:
		list(){
			length=0;
			root = new Node<T>();
			tail=root;
			tail->next= new Node<T>();
		}
	
		list(int n,const T& value=T()): list<T>(){ insert(end(),n,value);}
		
		list(Node<T>* first, Node<T>* last): list<T>(){
			while(first != last){
				insert(end(),first->data);
				first=first->next;
			}
		}
		
		list(const list<T>& rhs): list<T>(rhs.begin(),rhs.end()){}
		
		~list(){ //Y�k�c� Fonksiyon
			clear();
			delete tail->next;
			delete tail;
		}
	
		list<T>& operator=(const list<T>& rhs){return assign(rhs);} //E�ittir operat�r� ile listler aras� kopyalama
		
		list<T>& assign(const list<T>& rhs){ //atama fonskiyonu
			clear();
			Node<T>* tmp=rhs.begin();
			while(tmp != rhs.end()){
				push_back(tmp->data);
				tmp=tmp->data;
			}
			return *this;
		}
		
		Node<T>* begin()const{return root->next;} //ba�lang�� 
		Node<T>* end()const{return tail->next;} //Biti�
		bool isEmpty()const{return begin()==end();} //Bo� mu sorgu kontrol�
		int size()const{return length;} //Size sorgusu
		
		void push_back(const T& value){ insert(end(),value);} //En sona ekleme fonksiyonu
		void push_front(const T& value){ insert(begin(),value);} //En ba�a ekleme fonksiyonu
		
		void insert(Node<T>* pos,const T& value){ //Ekleme fonskiyonu
			if(pos==end()){
				tail->next= new Node<T>(value,end());
				tail=tail->next;
			}else{
				Node<T>* tmp=findPrev(pos);
				if(tmp == end())
					throw "Error: list::insert() for pos in not list";
				tmp->next=new Node<T>(value,tmp->next);	
			}
			length++;
		}
		
		void insert(Node<T>* pos,int n,const T& value){ //Ekleme fonskiyonu
			for(int i=0;i<n;i++)
				insert(pos,value);
		}
		
		void insert(Node<T>* pos,Node<T>* first,Node<T>* last){ //Ekleme fonskiyonu
			while(first != last){
				insert(pos,first->data);
				first=first->next;
			}
		}
		
		void erase(Node<T>* pos){ //Silme fonskiyonu
			if(isEmpty())
				throw "Error: list::erase() icin liste bos";
			Node<T>* prev= root;
			if(pos  == end() || pos == tail )
			{
				pos=tail;
				prev= findPrev(pos);
				prev->next=pos->next;
				tail=prev;
			}
			else{
				prev=findPrev(pos);
				if(prev== end())
					throw "Error : list::erase() liste yok";
				prev->next= pos->next;		
			}
			delete pos;
			length--;
		}
			
		void erase(Node<T>* first,Node<T>* last){ //Silme fonskiyonu
			Node<T>* tmp;
			while(first != last){
				tmp=first;
				first=first->next;
				erase(tmp);
			}
		}	
		
		void clear(){ //Temizleme Fonksiyonu
			erase(begin(),end());
		}
		
		T front()const{ //Ba�taki de�eri d�nd�rme
			if(isEmpty())
				throw "Error: list::front() liste bos";
			return begin()->data;	
		}
		
		T back()const{ //Sondaki de�eri d�nd�rme
			if(isEmpty())
				throw "Error: list::back() liste bos";
			return tail->data;	
		}
		
		void pop_front(){ //Ba�tan eleman ��karma
			try{erase(begin());}
			catch(const char* ex){throw "Error: list::pop_front() liste bos";}
		}
		
		void pop_back(){ //Sondan eleman ��karma
			try{erase(end());}
			catch(const char* ex){throw "Error: list::pop_back() liste bos";}
		}
		
		void print()const{ //Yazd�rma fonksiyonu
			Node<T>* tmp = begin();
			while(tmp != end()){
				cout<<tmp->data<<" ";
				tmp=tmp->next;
			}
			cout<<endl;
		}
};

template<class T>
class Stack:private list<T>{ //Y���n s�n�f� tasar�m� listeden kal�t�m alarak
	public:
		Stack():list<T>(){}
		bool isEmpty()const {return list<T>::isEmpty();} //Bo� mu sorgusu
		void push(const T&value){ list<T>::push_front(value); } //Ekleme
		void pop() //��karma
		{
		try{list<T>::pop_front();}
		catch(const char* ex){throw "Error: Stack::pop() for stack is empty";}
		}
		int size()const{ return list<T>::size();  } //Size sorgusu
		T top()const
		{ 
		try{return list<T>::front(); }
		catch(const char* ex){throw "Error: Stack::top() for stack is empty";}
		}
		void print()const{ list<T>::print(); } //yazd�rma
};

template<class T,class Container = list<T> > //Kuyruk s�n�f� tasar�m� listeyi �zellik gibi alarak
class Queue{
	Container cont; //�zellik de�i�keni
	public:
		bool isEmpty()const{ return cont.isEmpty(); } //Bo� mu sorgusu
		void enqueue(const T& value){ cont.push_back(value); }	 //Ekleme	
		void dequeue(){ cont.pop_front(); } //��karma
		T front()const{ return cont.front(); } //En ba�
		T back()const{ return cont.back(); } //En son
		void print()const{ cont.print(); } //Yazd�rma
		int size()const{ return cont.size(); } //Size
};

int HacimBul(int GonderiID){ //Hacim bulma fonksiyonu
	int hacim;
	if(GonderiID==1) //�f Sorgusu
		hacim=1;
	else if(GonderiID==2) //�f Sorgusu
		hacim=3; 
	else if(GonderiID==3) //�f Sorgusu
		hacim=5;
	else if(GonderiID==4) //�f Sorgusu
		hacim=1;
	else if(GonderiID==5) //�f Sorgusu
		hacim=3;
	else if(GonderiID==6) //�f Sorgusu
		hacim=5;
	cout<<"Hacim Bulundu:"<<hacim<<endl;
}
void NakliyeAraciYukleme(){} //NakliyeAraciYukleme fonksiyonu
void NakliyeAraciIndirme(){} //NakliyeAraciIndirme fonksiyonu
void DagitimAracinaYukleme(){} //DagitimAracinaYukleme fonksiyonu
int SaatToplama(int Saat, int GonderiYuklemeSuresi){ //SaatToplama fonksiyonu
	int sonuc;
	sonuc=Saat+GonderiYuklemeSuresi;
	return sonuc;
}

int main(int argc, char** argv) { //Main fonskiyon
	setlocale(LC_ALL, "Turkish"); //T�rk�e karakter
	ifstream file("gonderi.txt"); //Dosyay� a�ma
 	if(!file.is_open()){ //Dosya a��ld� m� sorgusu
  	cout<<"Dosya A��lmad�"<<endl;
  	return 0;
  	}
  	Queue<string> q; //kuyruk tan�m
  	list<string> l; //Liste tan�m
  	Stack<string> s; //y���n tan�m
   	string id,line,yas,yas2; //De�i�kenler
  	while(getline(file,line))
	{
		stringstream ss(line); 
		getline(ss,id,','); 
		for(int i=0;i<1;i++)
			q.enqueue(id); //Txt den kuyru�a veri aktar�m�
		
		getline(ss,yas,',');
		for(int i=0;i<1;i++)
			l.push_back(yas); //Txt den listeye veri aktar�m�
		
		getline(ss,yas2,',');
		for(int i=0;i<1;i++)
			s.push(yas2);	//Txt den y���na veri aktar�m�
	}
	string dizi1[]={"07:00 Genel merkez","08:00 �ube1 e var��","08:30 �ube1 den hareket","08:50 �ube2 e var��","09:20 �ube2 den hareket",
	"09:40 �ube3 e var��","10:10 �ube3 den hareket","10:30 �ube4 e var��","11:00 �ube4 den hareket","11:20 �ube5 e var��","11:50 �ube 5 den hareket",
	"12:50 Genel merkez"}; //Nakliye i�lemleri dizisi
	for(int i=0; i<12;i++)
		cout<<dizi1[i]<<endl; //Nakliye i�lemleri dizisini yazd�rma
	cout<<endl;
	ofstream nakliye; 
	nakliye.open("Nakliye.txt"); //Nakliye i�lemleri txt
	for(int i=0; i<12;i++)
		nakliye << dizi1[i]<<endl; //Nakliye i�lemlerini txt ye atma
	cout<<"Nakliye.txt olu�turuldu.."<<endl;
	nakliye.close();
	cout<<endl;
	Subeler s1("1.Sube",1); //�ube olu�turma
	Subeler s2("2.Sube",2); //�ube olu�turma
	Subeler s3("3.Sube",3); //�ube olu�turma
	Subeler s4("4.Sube",4); //�ube olu�turma
	Subeler s5("5.Sube",5); //�ube olu�turma
	NakliyeArac na1(1,1,"07.00","08.00"); //NakliyeArac olu�turma
	Arac a1(1,300,1); //Ara� olu�turma
	Arac a2(2,300,2); //Ara� olu�turma
	Arac a3(3,300,3); //Ara� olu�turma
	Arac a4(4,300,4); //Ara� olu�turma
	Arac a5(5,300,5); //Ara� olu�turma
	
	string z1[]={"G003","G010","G014"}; //Da��t�m bilgileri
	string z2[]={"08:31:00","08:31:06","08:31:12"}; //Da��t�m bilgileri
	ofstream sube1; 
	sube1.open("Dag�t�m1.txt"); //Da��t�m txt olu�turma
	for(int i=0; i<3;i++)
		sube1 << z1[i]<<","<<"1"<<","<<z2[i]<<endl; //Da��t�m bilgilerini txt ye yazd�rma
	cout<<"Dag�t�m1.txt olu�turuldu.."<<endl;
	sube1.close();
	
	string z3[]={"G007","G011","G016"}; //Da��t�m bilgileri
	string z4[]={"09:21:00","09:21:30","09:22:00"}; //Da��t�m bilgileri
	ofstream sube2; 
	sube2.open("Dag�t�m2.txt"); //Da��t�m txt olu�turma
	for(int i=0; i<3;i++)
		sube2 << z3[i]<<","<<"2"<<","<<z4[i]<<endl;  //Da��t�m bilgilerini txt ye yazd�rma
	cout<<"Dag�t�m2.txt olu�turuldu.."<<endl;
	sube2.close();
		
	string z5[]={"G015","G026","G031"}; //Da��t�m bilgileri
	string z6[]={"10:11:00","10:12:00","10:13:00"}; //Da��t�m bilgileri
	ofstream sube3; 
	sube3.open("Dag�t�m3.txt"); //Da��t�m txt olu�turma
	for(int i=0; i<3;i++)
		sube3 << z5[i]<<","<<"3"<<","<<z6[i]<<endl; //Da��t�m bilgilerini txt ye yazd�rma
	cout<<"Dag�t�m3.txt olu�turuldu.."<<endl;
	sube3.close();
	
	string z7[]={"G001","G005","G009"}; //Da��t�m bilgileri
	string z8[]={"11:00:00","11:00:06","11:00:12"}; //Da��t�m bilgileri
	ofstream sube4; 
	sube4.open("Dag�t�m4.txt"); //Da��t�m txt olu�turma
	for(int i=0; i<3;i++)
		sube4 << z7[i]<<","<<"4"<<","<<z8[i]<<endl; //Da��t�m bilgilerini txt ye yazd�rma
	cout<<"Dag�t�m4.txt olu�turuldu.."<<endl;
	sube4.close();
	
	string z9[]={"G002","G004","G006"}; //Da��t�m bilgileri
	string z10[]={"11:50:00","11:51:00","11:52:00"}; //Da��t�m bilgileri
	ofstream sube5; 
	sube5.open("Dag�t�m5.txt"); //Da��t�m txt olu�turma
	for(int i=0; i<3;i++)
		sube5 << z9[i]<<","<<"5"<<","<<z10[i]<<endl; //Da��t�m bilgilerini txt ye yazd�rma
	cout<<"Dag�t�m5.txt olu�turuldu.."<<endl;
	sube5.close();
	
	return 0;
}
