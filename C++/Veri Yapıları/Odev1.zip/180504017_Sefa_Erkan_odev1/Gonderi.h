#include <iostream> 
using namespace std;
#ifndef _GONDERI_H_
#define _GONDERI_H_

class Gonderi{ //G�nderi s�n�f� tan�mlama
	private://�zel
		int GonderiID; //GonderiID
		int GonderiTurID; //GonderiTurID
 		int GonderiOncelik; //GonderiOncelik
		int GonderiHacim; // GonderiHacim
		int SubeID; //SubeID
	public: //A��k
		Gonderi(int,int,int,int,int); //Parametreli Kurucu
		int getGonderiID(); //getter
		void setGonderiID(int GonderiID); //Setter
		int getGonderiTurID();	//getter
		void setGonderiTurID(int GonderiTurID); //Setter
		int getGonderiOncelik();	//getter
		void setGonderiOncelik(int GonderiOncelik); //Setter
		int getGonderiHacim();	//getter
		void setGonderiHacim(int GonderiHacim); //Setter
		int getSubeID();	//getter
		void setSubeID(int SubeID); //Setter
		void print();
};
#include "F.cpp"
#endif
